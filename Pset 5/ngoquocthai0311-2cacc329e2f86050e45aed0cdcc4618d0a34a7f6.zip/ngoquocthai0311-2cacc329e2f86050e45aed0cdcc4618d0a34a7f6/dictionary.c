// Implements a dictionary's functionality
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <strings.h>
#include <string.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 26;

// Hash table
node *table[N];
int count_dict = 0;
// Returns true if word is in dictionary else false
bool check(const char *word)
{
    // TODO
    int index = hash(word);
    for (node *tmp = table[index]; tmp != NULL; tmp = tmp->next)
    {
        // compare insensitive case
        if (strcasecmp(tmp->word, word) == 0)
        {
            return true;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO
    return tolower(word[0]) - 'a';
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    // TODO
    char word[LENGTH + 1];
    FILE *file_ptr = fopen(dictionary, "r");
    if (file_ptr == NULL)
    {
        unload();
        return false;
    }
    // check if reaching the end of the file
    while (fscanf(file_ptr, "%s", word) != EOF)
    {
        node *temp = malloc(sizeof(node));
        if (temp == NULL)
        {
            free(temp);
            unload();
            return false;
        }
        strcpy(temp->word, word);
        // get the index of the word.
        int index = hash(word);
        if (table[index] == NULL)
        {
            table[index] = temp;
            temp->next = NULL;
        }
        else
        {
            // put the word following the linked list at the tablel[index]
            for (node *tmp = table[index]; tmp != NULL; tmp = tmp->next)
            {
                if (tmp->next == NULL)
                {
                    tmp->next = temp;
                    temp->next = NULL;
                }
            }
        }
        // increment the word counted in dictionary
        count_dict++;
    }
    fclose(file_ptr);
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    return count_dict;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];
        while (cursor != NULL)
        {
            node *temp = cursor;
            cursor = cursor->next;
            free(temp);
        }
        return true;
    }
    return false;
}
